<?php
function usuarioOk($usuario, $contraseña) :bool {
   return (strlen($usuario) >= 8  && $usuario == strrev($contraseña));
}

