<div>
<b> Detalles:</b><br>
<table>
<tr><td>Longitud:          </td><td><?= strlen($_REQUEST['comentario']) ?></td></tr>
<tr><td>Nº de palabras:    </td><td>6</td></tr><?= contPalabras    ($_REQUEST['comentario']) ?></td></tr>
<tr><td>Letra + repetida:  </td><td>a</td></tr><?= letraRepe  ($_REQUEST['comentario']) ?></td></tr>
<tr><td>Palabra + repetida:</td><td>Hola</td></tr><?= palabraRepe($_REQUEST['comentario']) ?></td></tr>
</table>
</div>
</table>
</div>
<?php 


 
 function letraRepe ($cadena){
    $veces = 0;
    $letra = 'a'; 
    $tamaño = strlen($cadena);
    for ($i=0; $i<$tamaño; $i++ ) {
        $veces1 = 1;
        $letrai = $cadena[$i];
        for ($j=$i+1; $j<$tamaño; $j++ ){
            if ( $letrai == $cadena[$j]){
                $veces1++;
            }
        }
        if ( $veces1 > $veces){
                $letra = $letrai;
                $veces = $veces1;
        }
      }
    return $letra;  
 }

 function contPalabras ($cadena){
    return str_word_count($cadena,0);
 }

 function palabraRepe ($cadena){
    $palabra = str_word_count($cadena,1);
    $palabras = array_count_values($palabra);
    asort($palabras);
    return array_key_last($palabras); 
 }

?>


